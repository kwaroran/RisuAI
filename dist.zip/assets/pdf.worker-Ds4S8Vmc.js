const e="/assets/pdf.worker-CDGIelR-.js";export{e as default};
